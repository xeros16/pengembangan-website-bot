(() => {
  const root = document.documentElement;
  if (!('IntersectionObserver' in window)) return;
  const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');
  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      observer.unobserve(entry.target);
      const element = entry.target;
      if (reducedMotion.matches || root.dataset.pvMotion === 'off' || element.matches(':focus-within')) continue;
      const type = element instanceof HTMLImageElement ? 'media' : 'copy';
      const clear = event => {
        if (event.target !== element || !['edition-enter', 'edition-media-enter'].includes(event.animationName)) return;
        delete element.dataset.editionVisible;
        element.removeEventListener('animationend', clear);
        element.removeEventListener('animationcancel', clear);
      };
      element.addEventListener('animationend', clear);
      element.addEventListener('animationcancel', clear);
      element.dataset.editionVisible = type;
    }
  }, { threshold: 0.16 });

  const sections = document.querySelectorAll(
    '.edition-hero-copy, .pv-showcase-heading > div, .pv-journey-grid, ' +
    '.edition-directory-heading, .company-editorial-business .company-editorial-hero > div:first-child, ' +
    '.edition-case-opening .case-heading',
  );
  for (const section of sections) {
    const blocks = section.querySelectorAll(':scope > :is(h1,h2,p,.edition-actions,.pv-journey-card)');
    blocks.forEach((element, index) => {
      if (index) element.style.setProperty('--edition-reveal-step', Math.min(index, 4));
      observer.observe(element);
    });
  }
  for (const element of document.querySelectorAll(
    '.edition-hero-art img, .edition-case-opening .case-cover img, .pv-selected-work-image img',
  )) {
    observer.observe(element);
  }
  window.addEventListener('pagehide', event => {
    if (!event.persisted) observer.disconnect();
  });
})();
