# PIR Visuals 3.70.0

- **Beranda.** Galeri komunitas tampil tepat setelah hero. Tautan **Lihat karya komunitas** membawa pengunjung langsung ke galeri dan memindahkan fokus keyboard ke sana.
- **Jelajahi.** Pembuka halaman lebih ringkas. Kartu desainer menampilkan sampul karya yang sudah disetujui jika tersedia dan membuka detail karya saat ditekan.
- **Profil dan detail karya.** Pratinjau di profil memiliki interaksi yang mengikuti pengaturan pengurangan gerak. Halaman detail membuka dengan judul, pembuat, dan sampul karya. Informasi proyek serta navigasi bagian tampil setelah pembuka.

## Instalasi dan preview

Gunakan ZIP update untuk checkout **3.69.0**. Gunakan ZIP source lengkap untuk instalasi baru atau versi lebih lama. Siapkan konfigurasi MongoDB dan penyimpanan dengan mengikuti [panduan instalasi](PIR-3.68-INSTALASI.md).

Dari direktori `portfolio-website`, jalankan `npm ci` lalu `npm run preview`. Setelah terminal menampilkan **Listening**, buka alamat yang tercetak. Port default preview adalah 3080.

Untuk rollback, arahkan kembali servis ke source dan dependensi 3.69.0 dengan konfigurasi dan penyimpanan yang sama.

## Verifikasi

- Chromium desktop dan ponsel mencatat 27 tes lulus. Satu tes khusus ponsel dilewati pada desktop.
- Sembilan smoke test website lulus. Pemeriksaan sampul juga mengonfirmasi bahwa karya milik profil privat tidak muncul di kartu, detail, media, atau sitemap.
- Suite Node website mencatat 683 lulus dan 130 gagal, dengan daftar kegagalan yang sama seperti 3.69.0.
- Screenshot sebelum dan sesudah memakai data sintetis. Pengujian menggunakan Chromium dan MongoDB lokal. Deployment produksi belum diverifikasi.
