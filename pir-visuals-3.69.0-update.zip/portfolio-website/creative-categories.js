export const creativeCategories = [
  { title:'Brand Identity', description:'Identitas yang konsisten, dari logo hingga sistem visual yang membangun karakter brand.', glyph:'Aa', terms:['brand','branding','identity','logo'] },
  { title:'UI/UX Design', description:'Pengalaman digital yang intuitif, terarah, dan terasa mudah digunakan.', glyph:'⌘', terms:['ui/ux','ui ux','user interface','user experience','product design'] },
  { title:'Graphic Design', description:'Komunikasi visual untuk campaign, editorial, poster, dan kebutuhan komunikasi brand.', glyph:'✳', terms:['graphic','poster','editorial','layout'] },
  { title:'Illustration', description:'Bahasa visual yang khas melalui karakter, gambar, dan cerita ilustratif.', glyph:'◉', terms:['illustration','illustrator','ilustrasi'] },
  { title:'Motion Design', description:'Gerak, ritme, dan storytelling untuk membuat pesan lebih hidup.', glyph:'↗', terms:['motion','animation','animasi'] },
  { title:'3D Design', description:'Bentuk, ruang, material, dan visualisasi tiga dimensi.', glyph:'3D', terms:['3d','three-dimensional','render','cgi'] },
  { title:'Packaging', description:'Kemasan yang menarik perhatian sekaligus menyampaikan karakter produk.', glyph:'▧', terms:['packaging','kemasan','label'] },
  { title:'Social Media', description:'Konten dan sistem visual yang dirancang untuk kanal sosial.', glyph:'#', terms:['social media','social','content','feed'] },
  { title:'Web Design', description:'Website dan landing page yang menghubungkan estetika dengan tujuan bisnis.', glyph:'⌘', terms:['web','website','landing page'] },
  { title:'Photography', description:'Foto produk, portrait, dan visual storytelling dengan perspektif yang kuat.', glyph:'◌', terms:['photo','photography','fotografi'] },
];

// A curated label expands to the same legacy terms used on the category index.
export function categoryFilter(value, secondaryField) {
  const label = String(value || '').trim();
  if (!label) return {};
  const aliases = { branding: 'brand identity', 'ui/ux': 'ui/ux design' };
  const key = label.toLowerCase();
  const match = creativeCategories.find(item => item.title.toLowerCase() === (aliases[key] || key));
  const terms = match?.terms || [label];
  const regex = terms.map(term => term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  const query = { $regex: regex, $options: 'i' };
  return { $or: [{ category: query }, { [secondaryField]: query }] };
}
