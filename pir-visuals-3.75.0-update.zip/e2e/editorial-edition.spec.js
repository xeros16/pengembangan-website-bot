import { test, expect } from '@playwright/test';

test.use({ reducedMotion: 'reduce' });

test('navigation uses a single palette with a stored theme and a dark system preference', async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem('pir-appearance', 'dark'));
  await page.emulateMedia({ colorScheme: 'dark' });
  await page.goto('/');
  await expect(page.locator('.edition-hero h1')).toBeVisible();
  const image = page.locator('.edition-hero-art img');
  await expect.poll(() => image.evaluate(element => element.naturalWidth)).toBeGreaterThan(0);
  const navigation = page.locator('#main-nav');
  const menu = page.getByRole('button', { name: 'Buka menu navigasi' });
  if (await menu.isVisible()) await menu.click();
  await expect(page.locator('[data-appearance-toggle],[data-theme-toggle]')).toHaveCount(0);
  await expect(navigation.getByRole('button', { name: 'Cari cepat' })).toBeVisible();
  await expect(page.locator('html')).toHaveCSS('color-scheme', 'light only');
  const header = page.locator('header.site-nav');
  const background = await header.evaluate(element => getComputedStyle(element).backgroundColor);
  await navigation.getByRole('link', { name: 'Jelajahi', exact: true }).click();
  await expect(page.locator('.edition-directory-hero h1')).toBeVisible();
  await expect(header).toHaveCSS('background-color', background);
  await page.emulateMedia({ colorScheme: 'light' });
  await expect(page.locator('html')).toHaveCSS('color-scheme', 'light only');
  await expect(header).toHaveCSS('background-color', background);
});

test('directory search can be submitted without opening the filter panel', async ({ page }) => {
  await page.goto('/discover');
  const filters = page.locator('[data-discovery-filters]');
  await filters.getByLabel('Kata kunci').fill('Sari & Rupa');
  await filters.getByRole('button', { name: 'Cari', exact: true }).click();
  await expect.poll(() => new URL(page.url()).searchParams.get('q')).toBe('Sari & Rupa');
  await expect(page.locator('[data-discovery-filters]').getByLabel('Kata kunci')).toHaveValue('Sari & Rupa');
  const canonical = page.locator('link[rel="canonical"]');
  await expect(canonical).toHaveAttribute('href', /\/discover$/);
});

test('public portfolio media and sitemap observe designer visibility', async ({ request }) => {
  const privateItem = process.env.E2E_PRIVATE_PORTFOLIO_ID;
  const publicItem = process.env.E2E_PUBLIC_PORTFOLIO_ID;
  test.skip(!privateItem || !publicItem, 'Configure the two IDs on a disposable database with approved items owned by a private and a public profile.');
  const [hidden, visible, sitemap] = await Promise.all([
    request.get(`/media/${encodeURIComponent(privateItem)}`),
    request.get(`/media/${encodeURIComponent(publicItem)}`),
    request.get('/sitemap.xml'),
  ]);
  expect(hidden.status()).toBe(404);
  expect(visible.status()).toBe(200);
  expect(visible.headers()['content-type']).toMatch(/^image\//);
  expect(sitemap.status()).toBe(200);
  expect(await sitemap.text()).not.toContain(`/work/${privateItem}`);
});

test('applied filters are removable, preserve sort, and reset the result page', async ({ page }) => {
  await page.goto('/discover?q=studio&location=Bandung&sort=name&page=8');
  await expect(page.getByRole('button', { name: /Filter & urutkan/ })).toHaveAttribute('aria-expanded', 'true');
  await expect(page.locator('.edition-sort-summary')).toContainText('Nama A–Z');
  await page.getByRole('link', { name: 'Hapus filter Lokasi: Bandung' }).click();
  const next = new URL(page.url());
  expect(next.searchParams.get('q')).toBe('studio');
  expect(next.searchParams.get('sort')).toBe('name');
  expect(next.searchParams.has('location')).toBe(false);
  expect(next.searchParams.has('page')).toBe(false);
  await expect(page.getByRole('link', { name: 'Hapus semua', exact: true }).first()).toBeVisible();
});

test('directory advanced filters expand and collapse with the keyboard', async ({ page }) => {
  await page.goto('/discover');
  const form = page.locator('[data-discovery-filters]');
  const toggle = form.getByRole('button', { name: 'Filter & urutkan' });
  const panel = form.locator('[data-filter-panel]');
  await expect(toggle).toHaveAttribute('aria-expanded', 'false');
  await expect(panel).toHaveAttribute('inert', '');
  await expect(panel).toBeHidden();
  await toggle.press('Enter');
  await expect(toggle).toHaveAttribute('aria-expanded', 'true');
  await page.keyboard.press('Tab');
  await expect(form.getByLabel('Skill', { exact: true })).toBeFocused();
  await toggle.press('Enter');
  await expect(panel).toBeHidden();
  await expect(toggle).toBeFocused();
});

test('the permanent palette keeps navigation, directory, business and login text readable', async ({ page }) => {
  await page.emulateMedia({ colorScheme: 'dark' });
  const surfaces = [
    ['/', [
      ['.edition-hero .edition-action', '.edition-hero .edition-action'],
      ['#karya-komunitas', '#pv-showcase-title'],
      ['#karya-komunitas', '.pv-showcase-heading > p'],
      ['[data-showcase-tab][aria-selected="true"]', '[data-showcase-tab][aria-selected="true"]'],
    ]],
    ['/discover', [
      ['header.site-nav', '.brand-copy strong'],
      ['.pv-discovery-stage', '.pv-directory-results > .section-head h2'],
      ['.pv-discovery-shell', '.pv-filter-keyword'],
      ['.pv-filter-keyword input', '.pv-filter-keyword input', '::placeholder'],
      ['.edition-search-button', '.edition-search-button'],
    ]],
    ['/for-business', [
      ['.company-editorial-copy', '.company-editorial-copy h2'],
      ['.company-editorial-copy', '.company-editorial-copy .copy h3'],
      ['.company-editorial-copy', '.company-editorial-copy .copy p'],
      ['.company-editorial-copy', '.company-editorial-copy .copy li'],
    ]],
    ['/studio', [
      ['.edition-studio-auth', '#studio-otp-help'],
      ['#studio-login-otp', '#studio-login-otp', '::placeholder'],
      ['.edition-studio-help', '.edition-studio-help li a'],
      ['.edition-studio-form > button', '.edition-studio-form > button'],
    ]],
  ];

  for (const [path, pairs] of surfaces) {
    await page.goto(path);
    await expect(page.locator('html')).toHaveCSS('color-scheme', 'light only');
    for (const [surface, text, pseudo] of pairs) {
      const [background, foreground] = await page.evaluate(([surface, text, pseudo]) => {
        const bg = getComputedStyle(document.querySelector(surface)).backgroundColor;
        const fg = getComputedStyle(document.querySelector(text), pseudo || null).webkitTextFillColor;
        return [bg, fg].map(color => {
          const channels = color.match(/\d+/g).slice(0, 3).map(value => Number(value) / 255);
          const linear = channels.map(value => value <= .04045 ? value / 12.92 : ((value + .055) / 1.055) ** 2.4);
          return .2126 * linear[0] + .7152 * linear[1] + .0722 * linear[2];
        });
      }, [surface, text, pseudo]);
      const contrast = (Math.max(background, foreground) + .05) / (Math.min(background, foreground) + .05);
      expect(contrast, `${path} ${text}`).toBeGreaterThanOrEqual(4.5);
    }
  }
});

test('editorial text and artwork animate once and honor motion preferences', async ({ page }) => {
  await page.addInitScript(() => {
    window.editionStarts = [];
    document.addEventListener('animationstart', event => {
      if (event.animationName === 'edition-enter' && event.target.id === 'edition-home-title') {
        window.editionStarts.push('title');
      }
      if (event.animationName === 'edition-media-enter' && event.target.closest('.edition-hero-art')) {
        window.editionStarts.push('artwork');
      }
    });
  });
  const starts = () => page.evaluate(() => window.editionStarts.sort());
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await page.goto('/');
  const artwork = page.locator('.edition-hero-art img');
  await artwork.scrollIntoViewIfNeeded();
  await page.locator('#edition-home-title').scrollIntoViewIfNeeded();
  await expect.poll(starts).toEqual(['artwork', 'title']);
  await expect(page.locator('#edition-home-title')).not.toHaveAttribute('data-edition-visible');
  await expect(artwork).not.toHaveAttribute('data-edition-visible');

  await page.evaluate(() => localStorage.setItem('pir_visuals_motion_v1', 'off'));
  await page.reload();
  await artwork.scrollIntoViewIfNeeded();
  await expect(page.locator('html')).toHaveAttribute('data-pv-motion', 'off');
  await expect(artwork).toHaveCSS('animation-name', 'none');
  expect(await starts()).toEqual([]);

  await page.evaluate(() => localStorage.removeItem('pir_visuals_motion_v1'));
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.reload();
  await artwork.scrollIntoViewIfNeeded();
  await expect(page.locator('html')).toHaveAttribute('data-pv-motion', 'off');
  await expect(artwork).toHaveCSS('animation-name', 'none');
  expect(await starts()).toEqual([]);
});

test('Studio sign-in separates the OTP instructions, submit button, and account help', async ({ page }, testInfo) => {
  await page.goto('/studio');
  const login = page.getByRole('form', { name: 'Designer Studio' });
  const otp = login.getByLabel('Kode OTP WhatsApp');
  const submit = login.getByRole('button', { name: 'Masuk' });
  await expect(otp).toHaveAccessibleDescription(/\.portfolio dashboard otp/);
  const helpBox = await page.locator('#studio-otp-help').boundingBox();
  const submitBox = await submit.boundingBox();
  expect(submitBox.y).toBeGreaterThanOrEqual(helpBox.y + helpBox.height);
  await page.getByText('Kirim ulang verifikasi email', { exact: true }).press('Enter');
  await expect(page.locator('form[action="/studio/resend-verification"]').getByLabel('Email akun')).toBeVisible();
  await expect(page.getByRole('link', { name: 'Lupa password' })).toHaveAttribute('href', '/studio/forgot');
  await login.getByLabel('Email akun').fill(`qa-${testInfo.project.name}@fixture.example`);
  await login.getByLabel('Password').fill('fixture-only-test');
  await otp.fill('123456');
  const [response] = await Promise.all([
    page.waitForResponse(res => res.request().method() === 'POST' && new URL(res.url()).pathname === '/studio/login'),
    submit.click(),
  ]);
  expect(response.status()).toBe(401);
  await expect(page.getByRole('alert')).toContainText('Login gagal');
});

test('an invalid project brief preserves the entered draft on the form', async ({ page }) => {
  const profile = process.env.E2E_DESIGNER_PATH;
  test.skip(!profile || !profile.startsWith('/designer/'), 'Needs a synthetic profile accepting project briefs');
  await page.goto(profile.replace('/designer/', '/contact/'));
  const brief = 'Tes brief lokal.\nBaris kedua untuk revisi desain.';
  await page.getByLabel('Nama kamu').fill('Klien Sintetis');
  await page.getByLabel('Email aktif untuk akses ruang proyek').fill('brief@fixture.example');
  await page.getByLabel('WhatsApp (opsional)').fill('nomor salah');
  await page.getByLabel('Brief proyek').fill(brief);
  const [response] = await Promise.all([
    page.waitForResponse(res => res.request().method() === 'POST' && new URL(res.url()).pathname.startsWith('/contact/')),
    page.getByRole('button', { name: 'Kirim brief ke desainer' }).click(),
  ]);
  expect(response.status()).toBe(400);
  await expect(page.getByRole('alert')).toContainText('Periksa nomor WhatsApp');
  await expect(page.getByLabel('Brief proyek')).toHaveValue(brief);
  await expect(page.getByLabel('Email aktif untuk akses ruang proyek')).toHaveValue('brief@fixture.example');
});

test('home offers a direct jump to the community work gallery', async ({ page }) => {
  test.skip(!process.env.E2E_PUBLIC_PORTFOLIO_ID, 'Needs seeded approved portfolio media');
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await page.goto('/');
  await expect(page.locator('#pv-intro-overlay')).toBeHidden();
  const jump = page.getByRole('link', { name: 'Lihat karya komunitas' });
  await expect(jump).toBeVisible();
  await expect(jump).toHaveAttribute('href', '#karya-komunitas');
  await jump.press('Enter');
  await expect(page).toHaveURL(/#karya-komunitas$/);
  await expect(page.locator('#karya-komunitas')).toBeFocused();
  await expect(page.locator('#pv-showcase-title')).toBeInViewport();
});

test('gallery controls stay above the work and preserve the chosen slide across categories', async ({ page }, testInfo) => {
  test.skip(!process.env.E2E_PUBLIC_PORTFOLIO_ID, 'Needs multiple seeded approved portfolio items');
  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await page.clock.install();
  await page.goto('/');
  await expect(page.locator('#pv-intro-overlay')).toBeHidden();
  const gallery = page.locator('#karya-komunitas');
  const latest = gallery.getByRole('tab', { name: 'Karya Terbaru' });
  const panel = gallery.getByRole('tabpanel', { name: 'Karya Terbaru' });
  const controls = panel.getByRole('group', { name: 'Navigasi Karya Terbaru' });
  const next = controls.getByRole('button', { name: 'Karya Terbaru berikutnya' });
  const current = controls.locator('[data-showcase-current]');
  const slide = panel.locator('.pv-showcase-slide.is-active');
  const image = slide.locator('.pv-showcase-art img');
  await expect(latest).toHaveAttribute('aria-selected', 'true');
  await image.scrollIntoViewIfNeeded();
  await expect.poll(() => image.evaluate(el => el.naturalWidth)).toBeGreaterThan(0);
  const controlsBox = await controls.boundingBox();
  const stageBox = await slide.boundingBox();
  expect(controlsBox.y + controlsBox.height).toBeLessThanOrEqual(stageBox.y + 1);
  if (testInfo.project.name === 'chromium-mobile') {
    const imageBox = await image.boundingBox();
    const copyBox = await slide.locator('.pv-showcase-copy').boundingBox();
    expect(imageBox.y + imageBox.height).toBeLessThanOrEqual(copyBox.y + 1);
    await expect(image).toHaveCSS('object-fit', 'contain');
  }

  await page.clock.fastForward(8400);
  await expect(current).toHaveText('1');
  await next.press('Enter');
  await expect(current).toHaveText('2');
  await expect(next).toBeFocused();
  await expect(gallery.getByRole('status')).toContainText('2 dari');
  await expect(panel.locator('[data-showcase-slide]:not([hidden])')).toHaveCount(1);
  await expect(panel.locator('[data-showcase-dot="1"]')).toHaveAttribute('aria-current', 'true');

  await latest.press('ArrowRight');
  await expect(gallery.getByRole('tab', { name: 'Karya Unggulan' })).toBeFocused();
  await expect(gallery.getByRole('tabpanel', { name: 'Karya Unggulan' })).toBeVisible();
  await gallery.getByRole('tab', { name: 'Karya Unggulan' }).press('Home');
  await expect(latest).toBeFocused();
  await expect(current).toHaveText('2');
  await panel.locator('[data-showcase-dot="0"]').click();
  await expect(current).toHaveText('1');
});

test('gallery heading and tabs keep their horizontal alignment when switching categories', async ({ page }, testInfo) => {
  test.skip(!process.env.E2E_PUBLIC_PORTFOLIO_ID, 'Needs seeded approved portfolio media');
  await page.goto('/');
  const gallery = page.locator('#karya-komunitas');
  const heading = gallery.locator('#pv-showcase-title');
  const latest = gallery.getByRole('tab', { name: 'Karya Terbaru', exact: true });
  const tabs = gallery.getByRole('tablist');
  const leftEdge = locator => locator.evaluate(el => Math.round(el.getBoundingClientRect().left));
  await latest.scrollIntoViewIfNeeded();
  const [initialHeading, initialTabs, initialTab] = await Promise.all([
    leftEdge(heading),
    leftEdge(tabs),
    leftEdge(latest),
  ]);
  expect(initialHeading).toBe(initialTab);

  if (testInfo.project.name === 'chromium-desktop') {
    const featured = gallery.getByRole('tab', { name: 'Karya Unggulan', exact: true });
    await featured.hover();
    const fill = tab => tab.evaluate(el => getComputedStyle(el).backgroundColor);
    expect(await fill(featured)).not.toBe(await fill(latest));
    await expect(featured).toHaveAttribute('aria-selected', 'false');
  }

  for (const name of ['Event PIR Visuals', 'Karya Termurah', 'Karya Terbaru']) {
    const tab = gallery.getByRole('tab', { name, exact: true });
    await tab.click();
    await expect(tab).toHaveAttribute('aria-selected', 'true');
    await expect(gallery.locator('[data-showcase-tab][aria-selected="true"]')).toHaveCount(1);
    expect(await leftEdge(heading)).toBe(initialHeading);
    expect(await leftEdge(tabs)).toBe(initialTabs);
  }

  const emptyPanel = gallery.locator('[data-showcase-panel]:has(.pv-showcase-empty)').first();
  if (await emptyPanel.count()) {
    const tabId = await emptyPanel.getAttribute('aria-labelledby');
    await gallery.locator(`#${tabId}`).click();
    const back = emptyPanel.getByRole('button', { name: 'Lihat karya terbaru' });
    await expect(back).toBeVisible();
    await back.press('Enter');
    await expect(latest).toBeFocused();
    await expect(latest).toHaveAttribute('aria-selected', 'true');
    expect(await leftEdge(heading)).toBe(initialHeading);
  }
});

test('a portfolio image leads to a published case study from a directory card', async ({ page, request }) => {
  test.skip(!process.env.E2E_PUBLIC_PORTFOLIO_ID, 'Needs seeded approved portfolio media');
  await page.goto('/discover');
  const preview = page.locator('.edition-card-work').first();
  await preview.scrollIntoViewIfNeeded();
  await expect.poll(() => preview.locator('img').evaluate(image => image.naturalWidth)).toBeGreaterThan(0);
  const path = await preview.getAttribute('href');
  expect(path).toMatch(/^\/work\//);
  expect((await request.get(path)).status()).toBe(200);
  await preview.click();
  await expect(page).toHaveURL(/\/work\//);
  const cover = page.locator('#case-cover img');
  await expect(cover).toBeInViewport();
  await expect.poll(() => cover.evaluate(image => image.naturalWidth)).toBeGreaterThan(0);
});
