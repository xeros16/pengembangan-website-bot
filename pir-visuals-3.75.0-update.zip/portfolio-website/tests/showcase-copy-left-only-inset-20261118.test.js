import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const css = fs.readFileSync(new URL('../pir-showcase-editorial.css', import.meta.url), 'utf8');
const edition = fs.readFileSync(new URL('../edition-assets/pir-edition.css', import.meta.url), 'utf8');
const server = fs.readFileSync(new URL('../server.js', import.meta.url), 'utf8');
const js = fs.readFileSync(new URL('../pir-home-showcase.js', import.meta.url), 'utf8');

const LEFT = 'clamp(108px, 8.8vw, 132px)';
const RIGHT = 'clamp(16px, 1.8vw, 24px)';

test('only the desktop left-copy inset is increased', () => {
  assert.ok(js.includes(`padding-left', '${LEFT}'`));
  assert.ok(css.includes(`padding-left: ${LEFT} !important`));
  assert.ok(server.includes(`padding-left: ${LEFT} !important`));
});

test('both desktop copy insets use the gallery gutter', () => {
  assert.match(edition, /\.pv-showcase-slide > \.pv-showcase-copy\s*\{\s*padding: 46px var\(--edition-gallery-gutter\) 42px !important/);
});

test('the artwork column keeps its media and object fit', () => {
  assert.match(server, /class="pv-showcase-art"/);
  assert.match(edition, /\.pv-showcase-art > :is\(img,video\)[^{]*\{[^}]*object-fit: contain !important/);
});

test('new runtime and asset cache keys are active', () => {
  assert.match(js, /root\.dataset\.copyInsetRuntime = '20261118l'/);
  assert.match(server, /pir-showcase-editorial\.css\?v=20261118-left-only-inset-l/);
  assert.match(server, /pir-home-showcase\.js\?v=20261118-left-only-inset-l/);
});
