import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const js = fs.readFileSync(new URL('../pir-home-showcase.js', import.meta.url), 'utf8');
const edition = fs.readFileSync(new URL('../edition-assets/pir-edition.css', import.meta.url), 'utf8');
const server = fs.readFileSync(new URL('../server.js', import.meta.url), 'utf8');

test('showcase heading and slide copy share the same CSS inset', () => {
  assert.match(edition, /:is\(\.pv-showcase-heading,\.pv-showcase-tabs\)[^{]*\{[^}]*padding-inline: var\(--edition-gallery-gutter\) !important/);
  assert.match(edition, /\.pv-showcase-slide > \.pv-showcase-copy\s*\{\s*padding: 46px var\(--edition-gallery-gutter\) 42px !important/);
});

test('category changes update the visible slide without computing heading offsets', () => {
  assert.match(js, /slide\.hidden = !active/);
  assert.match(js, /paint\(panel, indexByKey\.get\(key\) \|\| 0\)/);
  assert.doesNotMatch(js, /getBoundingClientRect|ResizeObserver/);
});

test('the heading alignment patch does not alter carousel sizing or artwork fitting', () => {
  assert.match(server, /pir-showcase-editorial\.css\?v=20261119-heading-zoom-safe-b/);
  assert.match(server, /pir-home-showcase\.js\?v=20261119-heading-align-active-slide-e/);
  assert.match(server, /class="pv-showcase-art"/);
});
