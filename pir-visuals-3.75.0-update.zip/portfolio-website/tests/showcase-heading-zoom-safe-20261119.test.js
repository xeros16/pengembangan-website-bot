import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';

const js = fs.readFileSync(new URL('../pir-home-showcase.js', import.meta.url), 'utf8');
const css = fs.readFileSync(new URL('../pir-showcase-editorial.css', import.meta.url), 'utf8');
const edition = fs.readFileSync(new URL('../edition-assets/pir-edition.css', import.meta.url), 'utf8');
const server = fs.readFileSync(new URL('../server.js', import.meta.url), 'utf8');
const responsive = css.slice(css.lastIndexOf('Zoom-safe showcase heading'));

test('the gallery uses one responsive gutter for its heading and controls', () => {
  assert.match(edition, /--edition-gallery-gutter: clamp\(18px, 5vw, 96px\)/);
  assert.match(edition, /\.pv-showcase-controls \{[^}]*padding: 10px var\(--edition-gallery-gutter\) 14px !important/);
});

test('category changes do not position the heading with inline styles', () => {
  assert.doesNotMatch(js, /headingTitleBlock|scheduleHeadingAlignment|style\.setProperty/);
  assert.match(edition, /\.pv-showcase-heading \{[^}]*grid-template-columns: minmax\(0, 1fr\)/);
});

test('responsive title sizing remains in place for narrow and zoomed layouts', () => {
  assert.match(responsive, /@media \(max-width: 900px\)/);
  assert.match(responsive, /grid-template-columns: minmax\(0, 1fr\)/);
  assert.match(responsive, /max-width: min\(12ch, 100%\)/);
  assert.match(responsive, /@media \(max-width: 560px\)/);
  assert.match(responsive, /overflow-wrap: break-word/);
});

test('the page loads the cache-busted heading assets', () => {
  assert.match(server, /pir-showcase-editorial\.css\?v=20261119-heading-zoom-safe-b/);
  assert.match(server, /pir-home-showcase\.js\?v=20261119-heading-align-active-slide-e/);
});

test('the passive tab style does not share the selected honey fill', () => {
  assert.match(edition, /\[data-showcase-tab\]\[aria-selected="true"\] \{[^}]*background: var\(--edition-honey\)/);
  assert.match(edition, /:not\(\[aria-selected="true"\]\):hover \{[^}]*background: #2d493a/);
});
