(() => {
  const root = document.querySelector('[data-pv-showcase]');
  if (!root) return;

  const tabs = [...root.querySelectorAll('[data-showcase-tab]')];
  const panels = [...root.querySelectorAll('[data-showcase-panel]')];
  if (!tabs.length || !panels.length) return;

  const latestTab = tabs.find(tab => tab.dataset.showcaseTab === 'latest') || tabs[0];
  let activeKey = latestTab.dataset.showcaseTab;
  const status = root.querySelector('[data-showcase-status]');
  const indexByKey = new Map();

  const getPanel = key => panels.find(panel => panel.dataset.showcasePanel === key);
  const getSlides = panel => [...panel.querySelectorAll('[data-showcase-slide]')];

  const classifyMedia = slide => {
    const art = slide?.querySelector('.pv-showcase-art');
    const media = art?.querySelector('img, video');
    if (!art || !media) return;
    const apply = (width, height) => {
      if (!width || !height) return;
      const ratio = width / height;
      art.classList.remove('is-portrait', 'is-landscape', 'is-square');
      art.classList.add(ratio < 0.86 ? 'is-portrait' : ratio > 1.18 ? 'is-landscape' : 'is-square');
    };
    if (media.tagName === 'IMG') {
      if (media.naturalWidth && media.naturalHeight) apply(media.naturalWidth, media.naturalHeight);
      else media.addEventListener('load', () => apply(media.naturalWidth, media.naturalHeight), { once: true });
    } else {
      if (media.videoWidth && media.videoHeight) apply(media.videoWidth, media.videoHeight);
      else media.addEventListener('loadedmetadata', () => apply(media.videoWidth, media.videoHeight), { once: true });
    }
  };

  panels.forEach(panel => getSlides(panel).forEach(classifyMedia));

  const paint = (panel, requestedIndex) => {
    const slides = getSlides(panel);
    if (!slides.length) return;
    const activeIndex = (requestedIndex + slides.length) % slides.length;
    indexByKey.set(panel.dataset.showcasePanel, activeIndex);
    slides.forEach((slide, index) => {
      const active = index === activeIndex;
      slide.classList.toggle('is-active', active);
      slide.hidden = !active;
      if (!active) slide.querySelector('video')?.pause();
    });
    const current = panel.querySelector('[data-showcase-current]');
    if (current) current.textContent = String(activeIndex + 1);
    panel.querySelectorAll('[data-showcase-dot]').forEach((dot, index) => {
      dot.setAttribute('aria-current', String(index === activeIndex));
    });
    return slides[activeIndex];
  };

  const select = (panel, requestedIndex) => {
    const current = indexByKey.get(activeKey) || 0;
    if (requestedIndex === current) return;
    const slide = paint(panel, requestedIndex);
    const title = slide?.querySelector('h3')?.textContent.trim();
    if (status && title) {
      status.textContent = `${indexByKey.get(activeKey) + 1} dari ${getSlides(panel).length}: ${title}`;
    }
  };

  const activate = key => {
    const panel = getPanel(key);
    if (!panel) return;
    activeKey = key;
    if (status) status.textContent = '';
    tabs.forEach(tab => {
      const active = tab.dataset.showcaseTab === key;
      tab.setAttribute('aria-selected', String(active));
      tab.tabIndex = active ? 0 : -1;
      tab.classList.toggle('is-active', active);
    });
    panels.forEach(item => {
      item.hidden = item !== panel;
      if (item.hidden) item.querySelectorAll('video').forEach(video => video.pause());
    });
    paint(panel, indexByKey.get(key) || 0);
  };

  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => activate(tab.dataset.showcaseTab));
    tab.addEventListener('keydown', event => {
      if (!['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const nextIndex = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
      tabs[nextIndex].focus();
      activate(tabs[nextIndex].dataset.showcaseTab);
    });
  });

  root.addEventListener('click', event => {
    if (event.target.closest('[data-showcase-empty-latest]')) {
      activate(latestTab.dataset.showcaseTab);
      latestTab.focus();
      return;
    }
    const control = event.target.closest('[data-showcase-dot],[data-showcase-prev],[data-showcase-next]');
    const panel = control?.closest('[data-showcase-panel]');
    if (!panel || panel.hidden) return;
    const current = indexByKey.get(activeKey) || 0;
    const target = control.dataset.showcaseDot === undefined
      ? current + (control.hasAttribute('data-showcase-prev') ? -1 : 1)
      : Number(control.dataset.showcaseDot);
    select(panel, target);
  });

  let gesture;
  root.addEventListener('touchstart', event => {
    const art = event.target.closest('.pv-showcase-art');
    if (!art || art.querySelector('video') || event.touches.length !== 1) {
      gesture = undefined;
      return;
    }
    const touch = event.touches[0];
    gesture = { key: activeKey, id: touch.identifier, x: touch.clientX, y: touch.clientY };
  }, { passive: true });
  root.addEventListener('touchcancel', () => { gesture = undefined; }, { passive: true });
  root.addEventListener('touchend', event => {
    const start = gesture;
    gesture = undefined;
    if (!start || start.key !== activeKey) return;
    const touch = Array.from(event.changedTouches).find(item => item.identifier === start.id);
    if (!touch) return;
    const dx = touch.clientX - start.x;
    const dy = touch.clientY - start.y;
    if (Math.abs(dx) < 52 || Math.abs(dx) < Math.abs(dy) * 1.4) return;
    const panel = getPanel(activeKey);
    if (getSlides(panel).length < 2) return;
    if (event.cancelable) event.preventDefault();
    select(panel, (indexByKey.get(activeKey) || 0) + (dx < 0 ? 1 : -1));
  }, { passive: false });

  activate(latestTab.dataset.showcaseTab);
  root.setAttribute('data-showcase-ready', '');
})();
