(() => {
  const root = document.querySelector('[data-pv-showcase]');
  if (!root) return;

  const tabs = [...root.querySelectorAll('[data-showcase-tab]')];
  const panels = [...root.querySelectorAll('[data-showcase-panel]')];
  if (!tabs.length || !panels.length) return;

  let activeKey = 'latest';
  const status = root.querySelector('[data-showcase-status]');
  const indexByKey = new Map();

  const getPanel = key => panels.find(panel => panel.dataset.showcasePanel === key);
  const getSlides = panel => [...panel.querySelectorAll('[data-showcase-slide]')];

  // Apply the desktop inset to the actual copy column at runtime.
  // Inline !important styles avoid stale/competing stylesheet rules.
  const copyInsetMedia = window.matchMedia('(min-width: 901px)');
  const applyCopyInset = () => {
    root.querySelectorAll('[data-pv-showcase-copy]').forEach(copy => {
      if (copyInsetMedia.matches) {
        copy.style.setProperty('box-sizing', 'border-box', 'important');
        copy.style.setProperty('padding-block', '46px 42px', 'important');
        copy.style.setProperty('padding-left', 'clamp(44px, 3.8vw, 56px)', 'important');
        copy.style.setProperty('padding-right', 'clamp(16px, 1.8vw, 24px)', 'important');
        copy.querySelectorAll('.pv-showcase-meta strong, .pv-showcase-byline a').forEach(item => {
          item.style.removeProperty('position');
          item.style.removeProperty('left');
          item.style.removeProperty('transform');
        });
      } else {
        copy.style.removeProperty('box-sizing');
        copy.style.removeProperty('padding-block');
        copy.style.removeProperty('padding-left');
        copy.style.removeProperty('padding-right');
        copy.querySelectorAll('.pv-showcase-meta strong, .pv-showcase-byline a').forEach(item => {
          item.style.removeProperty('position');
          item.style.removeProperty('left');
          item.style.removeProperty('transform');
        });
      }
    });
    root.dataset.copyInsetRuntime = '20261118m-left-shift';
  };
  applyCopyInset();
  copyInsetMedia.addEventListener?.('change', applyCopyInset);
  window.addEventListener('resize', applyCopyInset, { passive: true });

  // Align the section title's left edge with the actual text inset in the
  // active carousel copy panel. This avoids guessing with viewport-based
  // padding when the heading container and full-width carousel have
  // different parent gutters.
  const headingTitleBlock = root.querySelector('.pv-showcase-heading > div:first-child');
  // Keep the heading aligned with the active carousel copy at every
  // viewport width, including narrow browser windows and browser zoom.
  // The measured shift is clamped to the visible showcase bounds below.
  let headingAlignFrame = 0;
  const resetHeadingAlignment = () => {
    headingTitleBlock.style.removeProperty('left');
    headingTitleBlock.style.removeProperty('position');
    headingTitleBlock.style.removeProperty('transform');
    root.dataset.headingAlignRuntime = 'responsive-flow';
  };
  const alignHeadingToCarouselCopy = () => {
    if (!headingTitleBlock) return;
    // Hidden slides have no usable rectangle for aligning the heading.
    const activeCopy = root.querySelector(
      '[data-showcase-panel]:not([hidden]) .pv-showcase-slide.is-active [data-pv-showcase-copy]'
    );
    if (!activeCopy) {
      resetHeadingAlignment();
      return;
    }
    // Keep the current offset in place while measuring. Removing `left`
    // before every pass caused a visible snap to the default position during
    // slide changes. Subtract the current inline offset to recover the
    // title's stable, unshifted layout coordinate without moving it on screen.
    headingTitleBlock.style.setProperty('position', 'relative', 'important');
    const rootRect = root.getBoundingClientRect();
    const headingRect = headingTitleBlock.getBoundingClientRect();
    const copyRect = activeCopy.getBoundingClientRect();
    if (!headingRect.width || !copyRect.width || !rootRect.width) {
      resetHeadingAlignment();
      return;
    }
    const currentLeft = Number.parseFloat(headingTitleBlock.style.getPropertyValue('left')) || 0;
    const headingBaseLeft = headingRect.left - currentLeft;
    // The text starts at the copy panel's content edge, not at a heading
    // glyph box that can change width or animate as slides rotate.
    const copyStyle = window.getComputedStyle(activeCopy);
    const copyBorderLeft = Number.parseFloat(copyStyle.borderLeftWidth) || 0;
    const copyPaddingLeft = Number.parseFloat(copyStyle.paddingLeft) || 0;
    const copyContentLeft = copyRect.left + copyBorderLeft + copyPaddingLeft;
    const desiredShift = copyContentLeft - headingBaseLeft;
    // Clamp the shift so the entire title block always remains inside the
    // visible page, even at unusual desktop widths or non-default zoom levels.
    const safeLeft = Math.max(12, rootRect.left + 12);
    const safeRight = Math.min(window.innerWidth - 12, rootRect.right - 12);
    const minShift = safeLeft - headingBaseLeft;
    const maxShift = safeRight - (headingBaseLeft + headingRect.width);
    if (maxShift < minShift) {
      resetHeadingAlignment();
      return;
    }
    const shift = Math.max(minShift, Math.min(maxShift, desiredShift));
    headingTitleBlock.style.setProperty('left', `${shift.toFixed(2)}px`, 'important');
    root.dataset.headingAlignRuntime = '20261119d-base-rect-clamped';
  };
  const scheduleHeadingAlignment = () => {
    if (headingAlignFrame) window.cancelAnimationFrame(headingAlignFrame);
    headingAlignFrame = window.requestAnimationFrame(() => {
      headingAlignFrame = 0;
      alignHeadingToCarouselCopy();
    });
  };
  scheduleHeadingAlignment();
  window.addEventListener('resize', scheduleHeadingAlignment, { passive: true });
  document.fonts?.ready?.then(scheduleHeadingAlignment).catch?.(() => {});
  if ('ResizeObserver' in window) {
    const headingAlignObserver = new ResizeObserver(scheduleHeadingAlignment);
    headingAlignObserver.observe(root);
    if (headingTitleBlock) headingAlignObserver.observe(headingTitleBlock);
    const activeCopyHeading = root.querySelector('[data-showcase-panel]:not([hidden]) [data-pv-showcase-copy] h3');
    if (activeCopyHeading) headingAlignObserver.observe(activeCopyHeading);
  }

  const classifyMedia = slide => {
    const art = slide?.querySelector('.pv-showcase-art');
    const media = art?.querySelector('img, video');
    if (!art || !media) return;
    const apply = (width, height) => {
      if (!width || !height) return;
      const ratio = width / height;
      art.classList.remove('is-portrait', 'is-landscape', 'is-square');
      art.classList.add(ratio < 0.86 ? 'is-portrait' : ratio > 1.18 ? 'is-landscape' : 'is-square');
    };
    if (media.tagName === 'IMG') {
      if (media.naturalWidth && media.naturalHeight) apply(media.naturalWidth, media.naturalHeight);
      else media.addEventListener('load', () => apply(media.naturalWidth, media.naturalHeight), { once: true });
    } else {
      if (media.videoWidth && media.videoHeight) apply(media.videoWidth, media.videoHeight);
      else media.addEventListener('loadedmetadata', () => apply(media.videoWidth, media.videoHeight), { once: true });
    }
  };

  panels.forEach(panel => getSlides(panel).forEach(classifyMedia));

  const paint = (panel, requestedIndex) => {
    const slides = getSlides(panel);
    if (!slides.length) return;
    const activeIndex = (requestedIndex + slides.length) % slides.length;
    indexByKey.set(panel.dataset.showcasePanel, activeIndex);
    slides.forEach((slide, index) => {
      const active = index === activeIndex;
      slide.classList.toggle('is-active', active);
      slide.hidden = !active;
      if (!active) slide.querySelector('video')?.pause();
    });
    // The active slide is the alignment reference after a category or artwork change.
    scheduleHeadingAlignment();
    const current = panel.querySelector('[data-showcase-current]');
    if (current) current.textContent = String(activeIndex + 1);
    panel.querySelectorAll('[data-showcase-dot]').forEach((dot, index) => {
      dot.setAttribute('aria-current', String(index === activeIndex));
    });
    return slides[activeIndex];
  };

  const select = (panel, requestedIndex) => {
    const current = indexByKey.get(activeKey) || 0;
    if (requestedIndex === current) return;
    const slide = paint(panel, requestedIndex);
    const title = slide?.querySelector('h3')?.textContent.trim();
    if (status && title) {
      status.textContent = `${indexByKey.get(activeKey) + 1} dari ${getSlides(panel).length}: ${title}`;
    }
  };

  const activate = key => {
    const panel = getPanel(key);
    if (!panel) return;
    activeKey = key;
    if (status) status.textContent = '';
    tabs.forEach(tab => {
      const active = tab.dataset.showcaseTab === key;
      tab.setAttribute('aria-selected', String(active));
      tab.tabIndex = active ? 0 : -1;
      tab.classList.toggle('is-active', active);
    });
    panels.forEach(item => {
      item.hidden = item !== panel;
      if (item.hidden) item.querySelectorAll('video').forEach(video => video.pause());
    });
    paint(panel, indexByKey.get(key) || 0);
    scheduleHeadingAlignment();
  };

  tabs.forEach((tab, index) => {
    tab.addEventListener('click', () => activate(tab.dataset.showcaseTab));
    tab.addEventListener('keydown', event => {
      if (!['ArrowRight', 'ArrowLeft', 'Home', 'End'].includes(event.key)) return;
      event.preventDefault();
      const nextIndex = event.key === 'Home' ? 0 : event.key === 'End' ? tabs.length - 1 : (index + (event.key === 'ArrowRight' ? 1 : -1) + tabs.length) % tabs.length;
      tabs[nextIndex].focus();
      activate(tabs[nextIndex].dataset.showcaseTab);
    });
  });

  root.addEventListener('click', event => {
    const control = event.target.closest('[data-showcase-dot],[data-showcase-prev],[data-showcase-next]');
    const panel = control?.closest('[data-showcase-panel]');
    if (!panel || panel.hidden) return;
    const current = indexByKey.get(activeKey) || 0;
    const target = control.dataset.showcaseDot === undefined
      ? current + (control.hasAttribute('data-showcase-prev') ? -1 : 1)
      : Number(control.dataset.showcaseDot);
    select(panel, target);
  });

  let gesture;
  root.addEventListener('touchstart', event => {
    const art = event.target.closest('.pv-showcase-art');
    if (!art || art.querySelector('video') || event.touches.length !== 1) {
      gesture = undefined;
      return;
    }
    const touch = event.touches[0];
    gesture = { key: activeKey, id: touch.identifier, x: touch.clientX, y: touch.clientY };
  }, { passive: true });
  root.addEventListener('touchcancel', () => { gesture = undefined; }, { passive: true });
  root.addEventListener('touchend', event => {
    const start = gesture;
    gesture = undefined;
    if (!start || start.key !== activeKey) return;
    const touch = Array.from(event.changedTouches).find(item => item.identifier === start.id);
    if (!touch) return;
    const dx = touch.clientX - start.x;
    const dy = touch.clientY - start.y;
    if (Math.abs(dx) < 52 || Math.abs(dx) < Math.abs(dy) * 1.4) return;
    const panel = getPanel(activeKey);
    if (getSlides(panel).length < 2) return;
    if (event.cancelable) event.preventDefault();
    select(panel, (indexByKey.get(activeKey) || 0) + (dx < 0 ? 1 : -1));
  }, { passive: false });

  activate(tabs.find(tab => tab.dataset.showcaseTab === 'latest')?.dataset.showcaseTab || tabs[0].dataset.showcaseTab);
  root.setAttribute('data-showcase-ready', '');
})();
