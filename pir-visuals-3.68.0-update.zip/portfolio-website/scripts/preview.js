import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const port = Number(process.env.PIR_PREVIEW_PORT || 3080);
if (!Number.isInteger(port) || port < 1 || port > 65535) {
  console.error('PIR_PREVIEW_PORT harus berupa angka dari 1 sampai 65535.');
  process.exitCode = 1;
} else {
  const url = `http://127.0.0.1:${port}`;
  const child = spawn(process.execPath, [fileURLToPath(new URL('../server.js', import.meta.url))], {
    stdio: 'inherit',
    env: {
      ...process.env,
      NODE_ENV: 'development',
      PORTFOLIO_WEB_HOST: '127.0.0.1',
      PORTFOLIO_WEB_PORT: String(port),
      PORTFOLIO_PUBLIC_BASE_URL: url,
      SITE_URL: url,
      SMTP_HOST: '',
      SMTP_USER: '',
      SMTP_PASSWORD: '',
    },
  });
  child.on('error', error => {
    console.error(error.message);
    process.exitCode = 1;
  });
  child.on('exit', (code, signal) => {
    process.exitCode = code ?? (signal === 'SIGINT' ? 130 : 1);
  });
  process.on('SIGTERM', () => child.kill('SIGTERM'));
}
