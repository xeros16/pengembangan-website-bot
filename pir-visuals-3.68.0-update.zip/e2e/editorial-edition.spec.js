import { test, expect } from '@playwright/test';

test.use({ reducedMotion: 'reduce' });

test('the editorial header, theme and mobile navigation work together', async ({ page }) => {
  await page.goto('/');
  await expect(page.locator('.edition-hero h1')).toBeVisible();
  const image = page.locator('.edition-hero-art img');
  await expect.poll(() => image.evaluate(element => element.naturalWidth)).toBeGreaterThan(0);
  const navigation = page.locator('#main-nav');
  const menu = page.getByRole('button', { name: 'Buka menu navigasi' });
  if (await menu.isVisible()) await menu.click();
  const theme = navigation.getByRole('button', { name: 'Mode gelap' });
  await theme.click();
  await expect(page.locator('html')).toHaveAttribute('data-appearance', 'dark');
  await navigation.getByRole('link', { name: 'Jelajahi', exact: true }).click();
  await expect(page.locator('html')).toHaveAttribute('data-appearance', 'dark');
  await expect(page.locator('.edition-directory-hero h1')).toBeVisible();
});

test('directory search can be submitted without opening the filter panel', async ({ page }) => {
  await page.goto('/discover');
  const filters = page.locator('[data-discovery-filters]');
  await filters.getByLabel('Kata kunci').fill('Sari & Rupa');
  await filters.getByRole('button', { name: 'Cari', exact: true }).click();
  await expect.poll(() => new URL(page.url()).searchParams.get('q')).toBe('Sari & Rupa');
  await expect(page.locator('[data-discovery-filters]').getByLabel('Kata kunci')).toHaveValue('Sari & Rupa');
  const canonical = page.locator('link[rel="canonical"]');
  await expect(canonical).toHaveAttribute('href', /\/discover$/);
});

test('public portfolio media and sitemap observe designer visibility', async ({ request }) => {
  const privateItem = process.env.E2E_PRIVATE_PORTFOLIO_ID;
  const publicItem = process.env.E2E_PUBLIC_PORTFOLIO_ID;
  test.skip(!privateItem || !publicItem, 'Configure the two IDs on a disposable database with approved items owned by a private and a public profile.');
  const [hidden, visible, sitemap] = await Promise.all([
    request.get(`/media/${encodeURIComponent(privateItem)}`),
    request.get(`/media/${encodeURIComponent(publicItem)}`),
    request.get('/sitemap.xml'),
  ]);
  expect(hidden.status()).toBe(404);
  expect(visible.status()).toBe(200);
  expect(visible.headers()['content-type']).toMatch(/^image\//);
  expect(sitemap.status()).toBe(200);
  expect(await sitemap.text()).not.toContain(`/work/${privateItem}`);
});

test('applied filters are removable, preserve sort, and reset the result page', async ({ page }) => {
  await page.goto('/discover?q=studio&location=Bandung&sort=name&page=8');
  await expect(page.locator('.edition-sort-summary')).toContainText('Nama A–Z');
  await page.getByRole('link', { name: 'Hapus filter Lokasi: Bandung' }).click();
  const next = new URL(page.url());
  expect(next.searchParams.get('q')).toBe('studio');
  expect(next.searchParams.get('sort')).toBe('name');
  expect(next.searchParams.has('location')).toBe(false);
  expect(next.searchParams.has('page')).toBe(false);
  await expect(page.getByRole('link', { name: 'Hapus semua', exact: true }).first()).toBeVisible();
});

test('on mobile the collapsed filter controls cannot receive keyboard focus', async ({ page }, testInfo) => {
  test.skip(testInfo.project.name !== 'chromium-mobile', 'Mobile collapsible controls');
  await page.goto('/discover');
  const form = page.locator('[data-discovery-filters]');
  const toggle = form.getByRole('button', { name: 'Filter & urutkan' });
  await expect(toggle).toHaveAttribute('aria-expanded', 'false');
  await expect(form.locator('[data-filter-panel]')).toHaveAttribute('inert', '');
  await toggle.focus();
  await page.keyboard.press('Enter');
  await expect(toggle).toHaveAttribute('aria-expanded', 'true');
  await page.keyboard.press('Tab');
  await expect(form.getByLabel('Skill', { exact: true })).toBeFocused();
});

test('an invalid project brief preserves the entered draft on the form', async ({ page }) => {
  const profile = process.env.E2E_DESIGNER_PATH;
  test.skip(!profile || !profile.startsWith('/designer/'), 'Needs a synthetic profile accepting project briefs');
  await page.goto(profile.replace('/designer/', '/contact/'));
  const brief = 'Tes brief lokal.\nBaris kedua untuk revisi desain.';
  await page.getByLabel('Nama kamu').fill('Klien Sintetis');
  await page.getByLabel('Email aktif untuk akses ruang proyek').fill('brief@fixture.example');
  await page.getByLabel('WhatsApp (opsional)').fill('nomor salah');
  await page.getByLabel('Brief proyek').fill(brief);
  const [response] = await Promise.all([
    page.waitForResponse(res => res.request().method() === 'POST' && new URL(res.url()).pathname.startsWith('/contact/')),
    page.getByRole('button', { name: 'Kirim brief ke desainer' }).click(),
  ]);
  expect(response.status()).toBe(400);
  await expect(page.getByRole('alert')).toContainText('Periksa nomor WhatsApp');
  await expect(page.getByLabel('Brief proyek')).toHaveValue(brief);
  await expect(page.getByLabel('Email aktif untuk akses ruang proyek')).toHaveValue('brief@fixture.example');
});
