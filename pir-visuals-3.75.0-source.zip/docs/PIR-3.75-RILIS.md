# PIR Visuals 3.75.0

- **Judul dan tab galeri.** Posisi keduanya memakai jarak tepi yang sama di semua kategori, termasuk panel Event yang kosong. Pembuka yang lebih ringkas menampilkan karya sekitar 230 piksel lebih awal pada viewport desktop 1680 piksel.
- **Pilihan kategori.** Tab terpilih memakai latar madu. Sorotan mouse pada tab lain menggunakan hijau yang lembut agar pilihan aktif mudah dikenali.
- **Panel kosong.** Pesan ringkas disertai tombol **Lihat karya terbaru** jika karya tersedia. Saat galeri belum memiliki karya, tautan mengarah ke Jelajahi.

## Instalasi dan preview

Gunakan ZIP update dari **3.74.0** atau ZIP source lengkap untuk instalasi baru dan versi lebih lama. Ikuti [panduan instalasi](PIR-3.68-INSTALASI.md) untuk konfigurasi MongoDB dan penyimpanan.

Dari folder `portfolio-website`, jalankan `npm ci` dan `npm run preview`. Setelah status **Listening**, buka `http://127.0.0.1:3080` atau alamat yang tercetak di terminal.

## Verifikasi

- Posisi judul dan tab diperiksa pada lebar 320 hingga 1760 piksel. Screenshot perbandingan memakai data sintetis.
- Galeri dengan database kosong menampilkan tautan Jelajahi saat JavaScript dimatikan.
- Sembilan smoke test lulus. Suite Node mencatat 683 lulus dan 130 kegagalan yang sama dengan 3.74.0.
