# PIR Visuals 3.73.0

- **Warna.** Tema tunggal memakai krem hangat untuk halaman, hijau hutan untuk galeri komunitas, dan madu untuk judul, tombol utama, serta bagian pembuka Untuk Bisnis. Logo pir, foto editorial, dan karya desainer memberi tampilan ini karakter PIR Visuals. Ritme antara latar terang, gelap, dan aksen hangat terinspirasi dari [Bettr Academy](https://bettr.academy/).
- **Gerak.** Judul dan teks penting masuk secara bertahap. Gambar di beranda, karya pilihan, dan pembuka studi kasus bergerak singkat ketika terlihat. Ikon panah pada tombol editorial memberi respons saat disorot atau difokuskan. Animasi mengikuti kontrol gerak situs dan preferensi pengurangan gerak perangkat.
- **Pratinjau.** ZIP perbandingan berisi 20 screenshot desktop dan ponsel, serta video singkat animasi beranda. Screenshot memakai data sintetis.

## Instalasi dan preview

Gunakan ZIP update dari **3.72.0** atau ZIP source lengkap untuk instalasi baru dan versi lebih lama. Ikuti [panduan instalasi](PIR-3.68-INSTALASI.md) untuk konfigurasi MongoDB dan penyimpanan.

Dari folder `portfolio-website`, jalankan `npm ci` dan `npm run preview`. Setelah status **Listening**, buka `http://127.0.0.1:3080` atau alamat yang tercetak di terminal.

## Verifikasi

- 34 tes Chromium desktop dan ponsel lulus, termasuk pemeriksaan kontras dan pengurangan gerak.
- Sembilan smoke test website lulus. Suite Node mencatat 683 tes lulus dan 130 kegagalan yang sama dengan 3.72.0.
