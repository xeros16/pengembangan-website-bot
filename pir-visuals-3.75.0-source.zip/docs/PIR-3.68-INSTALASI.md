# PIR Visuals 3.68.0 — instalasi, preview, dan rollback

ZIP update 3.68.0 berlaku untuk source code 3.67.1. Untuk instalasi baru gunakan ZIP source lengkap. Bot tetap 6.7.13. Rilis ini menggunakan koleksi MongoDB, CMS, dan lokasi upload yang sama, tanpa migrasi schema.

## Update tanpa menimpa data

1. Simpan folder rilis lama beserta salinan konfigurasi, backup MongoDB, dan snapshot folder upload di lokasi privat.
2. Salin **source rilis lama** ke folder rilis baru. Ekstrak isi ZIP update ke folder rilis baru. ZIP hanya memuat file program dan panduan yang berubah. Pertahankan konfigurasi runtime, lokasi database, folder upload, dan direktori sesi WhatsApp.
3. Dari folder rilis baru jalankan `npm ci` dan `npm run website:install`. Gunakan Node.js 22 atau lebih baru. Periksa status website dengan MongoDB lokal atau staging sebelum berpindah versi.

## Preview dari Windows Command Prompt

Di Command Prompt, masuk ke folder proyek. Apabila MongoDB sudah dikonfigurasi, gunakan perintah berikut:

```cmd
cd /d E:\pengembangan-bot-grup-desain\portfolio-website
npm run preview
```

Buka `http://127.0.0.1:3080` setelah muncul pesan `Listening`. Untuk preview dengan data lokal terpisah, tetapkan MongoDB loopback secara eksplisit sebelum menjalankan perintah, sesuaikan port dengan instalasi MongoDB:

```cmd
set "MONGO_URI=mongodb://127.0.0.1:27017/pir_visuals_preview"
npm run preview
```

Jika port web terpakai, jalankan `set "PIR_PREVIEW_PORT=3089"` lalu ulangi `npm run preview`. Mode preview mengikat HTTP ke loopback dan menonaktifkan SMTP tanpa mengubah `.env`. Gunakan database sintetis untuk percobaan yang menulis data.

## Produksi dan rollback

Mode produksi tetap membutuhkan URL HTTPS. Ikuti [panduan deployment](PIR-3.67-DEPLOYMENT.md) dengan substitusi nama ZIP 3.68.0. [Laporan QA 3.68.0](PIR-3.68-QA.md) mencatat penghalang rilis.

Jika perlu rollback, hentikan servis, arahkan kembali ke folder rilis 3.67.1 beserta dependency yang sesuai, lalu mulai dengan konfigurasi database dan upload semula. Pertahankan data yang dibuat selama pengujian atau rilis. Pemulihan backup hanya diperlukan untuk pemulihan data yang memang dibutuhkan.
