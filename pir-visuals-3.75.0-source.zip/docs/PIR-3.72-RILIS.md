# PIR Visuals 3.72.0

- **Tema tetap.** Navigasi, latar halaman, dan formulir memakai palet hijau sage lembut dengan teks hijau tua. Website memakai palet yang sama saat preferensi perangkat berubah atau browser masih menyimpan pilihan tema lama. Tombol ganti tema dihapus dari navigasi.
- **Designer Studio.** Formulir login tampil lebih awal. Petunjuk OTP diletakkan tepat di bawah kolom kode dan tombol **Masuk** tampil di baris tersendiri. Bantuan akun berisi tautan daftar, reset password, aktivasi akun, dan formulir kirim ulang verifikasi email.

## Instalasi dan preview

Gunakan ZIP update dari checkout **3.71.0** atau ZIP source lengkap untuk instalasi baru dan versi lebih lama. Ikuti [panduan instalasi dan rollback](PIR-3.68-INSTALASI.md) untuk konfigurasi MongoDB dan penyimpanan.

Dari folder `portfolio-website`, jalankan `npm ci` dan `npm run preview`. Tunggu status **Listening**, lalu buka `http://127.0.0.1:3080` atau alamat yang tercetak di terminal.

## Verifikasi

- 32 tes Chromium desktop dan ponsel lulus, termasuk pengujian preferensi gelap perangkat, pilihan tema lama, kontras komponen, navigasi, dan pengiriman formulir login.
- Sembilan smoke test website lulus. Suite Node website mencatat 683 tes lulus dan 130 kegagalan yang sama dengan 3.71.0.
- Screenshot perbandingan memakai data sintetis. Pengujian dilakukan secara lokal.
