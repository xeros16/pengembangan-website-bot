# PIR Visuals 3.69.0

Pembaruan ini melanjutkan 3.68.0. Bot tetap 6.7.13. Website, bot, CMS, MongoDB, dan folder upload tetap kompatibel dengan data yang sudah ada. Tidak ada migrasi schema.

## Perubahan

- **Kategori dan Jelajahi** memakai aturan bidang kreatif yang sama. Karya berstatus disetujui hanya dihitung jika profil pembuatnya publik. Daftar karya terbaru dan karya terkait memeriksa visibilitas sebelum membatasi hasil. Label lama seperti Branding dan Logo Design tetap bisa ditemukan.
- **Profil desainer** kini menghormati pilihan bahasa Indonesia meskipun default profil bahasa Inggris. Kontrol bahasa menandai pilihan aktif. Perubahan ini berlaku untuk label yang sudah memiliki terjemahan.
- **Designer Studio** mempertahankan isian layanan dan catatan kalender saat validasi gagal. Penyimpanan mengarahkan browser kembali ke bagian Studio yang sesuai supaya reload tidak mengulang POST. Formulir baru mengirim status aktif atau nonaktif secara eksplisit, jadi menekan tindakan yang sama dua kali menghasilkan status yang sama.
- **Owner Dashboard** menampilkan total antrean dan jumlah yang terlihat. Daftar moderasi tetap mengambil 50 item tertua agar halaman tidak memuat seluruh antrean sekaligus.
- **Client Workspace** diverifikasi ulang bersama alur pengunjung, desainer, dan Owner. Brief, undangan melalui SMTP lokal, feedback, dan pembatasan sesi diuji menggunakan data sintetis.

## Verifikasi lokal

- 23 tes Playwright lulus, satu tes desktop dilewati karena khusus mobile.
- 14 pemeriksaan alur pengguna, 8 pemeriksaan regresi terarah, dan 9 smoke test lulus. Regresi terarah mencakup 13 karya profil privat yang peringkatnya lebih tinggi, hitungan karya publik, label lama, pemilihan bahasa, penyimpanan draft, reload, deaktifasi berulang, dan antrean lebih dari 50.
- Suite Node website mencatat 683 lulus dan 130 gagal. Jumlah kegagalan historis tidak bertambah dibanding 3.68.0. Pemeriksaan yang merujuk implementasi kategori lama diperbarui agar tetap menguji filter dan visibilitas. Tidak ada perubahan pada kode atau dependensi bot.
- Screenshot yang disertakan menggunakan data sintetis. SMTP eksternal, WhatsApp langsung, deployment produksi, dan browser selain Chromium belum diverifikasi pada rilis ini.

## Instalasi dan rollback

Gunakan **ZIP update 3.69.0** di checkout **3.68.0**. Untuk instalasi baru atau source yang lebih lama, gunakan ZIP source lengkap. Ekstrak ke direktori rilis terpisah, pertahankan konfigurasi runtime dan penyimpanan bersama, lalu jalankan `npm ci` dan `npm run website:install`.

Untuk preview Windows, jalankan `npm run preview` dari `portfolio-website` dan buka `http://127.0.0.1:3080` setelah status Listening. [Panduan preview dan rollback](PIR-3.68-INSTALASI.md) tetap berlaku dengan nama ZIP dan versi rilis yang sesuai. Untuk rollback, arahkan servis kembali ke source dan dependency 3.68.0 dengan konfigurasi dan data yang sama.
