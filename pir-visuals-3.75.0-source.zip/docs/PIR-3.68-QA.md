# PIR Visuals 3.68.0 — audit dan QA

Baseline yang dijalankan kembali adalah website 3.67.1 pada commit `c884335`. Pengujian memakai Node.js 24, Chromium, MongoDB 8 di loopback, media sintetis, serta SMTP lokal yang hanya menerima alamat fixture. Nomor WhatsApp diuji sampai respons redirect. Browser tidak membuka WhatsApp atau mengirim pesan nyata.

## Temuan dan perbaikan

| Prioritas | Temuan | Perbaikan dan bukti |
| --- | --- | --- |
| Tinggi | Pengiriman brief yang ditolak menampilkan teks mentah dan membuang empat isian. Baris baru dalam brief hilang saat normalisasi. | Formulir dapat dirender ulang dengan isian yang di-escape. Playwright mengirim nomor tidak valid, membaca kesalahan, lalu mengoreksi dan mengirim formulir asli. MongoDB menyimpan dua baris, dan SMTP lokal menerima undangan. |
| Tinggi | Kirim ulang feedback yang terlalu cepat menyebabkan pengguna kehilangan pesan. Kegagalan notifikasi sesudah penyimpanan dapat mengembalikan kegagalan untuk pesan yang sudah tercatat. | Respons 429 menampilkan draf dan petunjuk waktu percobaan ulang. Pesan yang tersimpan tetap dianggap terkirim. Browser memverifikasi draf, balasan tersimpan, CSRF, tautan sekali pakai, sesi kedaluwarsa, dan logout. |
| Sedang | Filter mobile yang tertutup masih dapat memasukkan kontrol ke urutan Tab. Sulit membedakan filter aktif dari isian form. | Kontrol tertutup dibuat inert, filter aktif dapat dihapus satu per satu, urutan hasil ditampilkan, dan penghapusan filter kembali ke halaman pertama. Link reset tersedia di hasil kosong. |
| Sedang | Tindakan yang sering dipakai Owner terkubur di dasbor panjang. | Akses antrean moderasi, editor beranda, dan pemeriksaan status sistem ditambahkan di atas dasbor. Ketiganya digunakan melalui Chromium. |
| Sedang | Gaya lama berbenturan dengan token mode gelap. | Warna tulisan, kartu, dan input di beranda, Jelajahi, brief, dan login diselaraskan. Hasil axe ditinjau kembali pada halaman yang terdampak. |
| Sedang | Gambar etalase dan segel footer diminta ketika halaman pertama kali dibuka. | Gambar di bawah lipatan dibuat lazy, dan video event menunggu pemutaran sebelum preload. |
| Operasional | Preview lokal Windows bisa mewarisi mode produksi. Audit CI juga memeriksa metadata Git dan arsip masukan. | Perintah preview memakai loopback HTTP dan menonaktifkan SMTP. CI mengaudit ekspor source; arsip input yang sudah dilacak tetap tersimpan. |

Kedua situs referensi dapat diakses pada sesi ini. Bettr Academy digunakan untuk hierarki dan jalur masuk berdasarkan tujuan, sedangkan The Rewilding Co. untuk susunan koleksi dan kontrol penelusuran. Identitas warna, ilustrasi botani, dan pengaturan CMS PIR dipertahankan.

## Hasil pengujian

| Pemeriksaan | 3.67.1 | 3.68.0 |
| --- | --- | --- |
| Smoke website | 9 lulus | 9 lulus |
| Playwright desktop dan mobile | 18 lulus | 23 lulus, 1 dilewati karena tes panel lipat khusus mobile |
| Node website | 682 lulus, 130 gagal | 682 lulus, 130 gagal |
| Node bot | 697 lulus, 1 gagal | Bot dan dependensinya tidak berubah |
| Alur manual terotomasi di Chromium | — | 14 pemeriksaan lulus mencakup pengunjung, Studio, klien, dan Owner |
| Axe, kontras warna | — | Tidak menemukan pelanggaran kontras pada beranda, Jelajahi, formulir brief, dan login Studio dalam mode terang dan gelap |
| Pemeriksaan layout | — | 48 pemeriksaan lulus pada 8 rute × 6 ukuran dari 320 sampai 1920 px |
| Preview loopback | — | Command preview teruji pada Linux dengan variabel mode produksi terpasang; HTTP produksi tetap ditolak |

Perintah utama di checkout:

```sh
npm run check
npm run website:check
npm test
npm run website:test
PORTFOLIO_SMOKE_BASE_URL=http://127.0.0.1:3088 npm run smoke --prefix portfolio-website
E2E_BASE_URL=http://127.0.0.1:3088 E2E_EXTERNAL_SERVER=true \
E2E_CHROMIUM_EXECUTABLE=/usr/bin/chromium E2E_DESIGNER_PATH=/designer/DSN-A001 \
E2E_PRIVATE_PORTFOLIO_ID=PF-D004 E2E_PUBLIC_PORTFOLIO_ID=PF-A001 npm run test:e2e
```

Arsip screenshot memuat pasangan sebelum dan sesudah pada 1440 dan 390 px, serta dua tangkapan tambahan Jelajahi dalam mode gelap. Seluruh akun, karya, dan proyek dalam screenshot adalah fixture.

Empat assertion yang terpengaruh perubahan kode diperbarui dengan perilaku yang sama atau lebih spesifik: tata letak hasil direktori, semantik formulir brief, dan dua pemeriksaan status proyek tertutup. Seluruhnya lulus. Kegagalan baseline yang masih terbuka mencakup versi historis yang ditulis literal, pemeriksaan struktur hero/CSS yang sudah diganti, serta dua suite yang mencari stylesheet atau server pada direktori lama. Kegagalan bot baseline mematok versi historis website. Suite Node tetap menjadi penghalang kesiapan produksi. Tidak ada klaim bahwa semua kegagalan baseline sekadar kosmetik.

## Pengukuran halaman

Chromium desktop, loopback, fixture yang sama, cache browser baru, tiga navigasi per halaman, resource luar diblokir. Waktu adalah median `loadEventEnd` lokal dari satu run. Kolom gambar adalah byte ter-encode untuk request gambar yang selesai, dan request menghitung respons yang membawa body terukur. Angka dapat berubah bergantung pada lazy loading dan beban mesin.

| Halaman | HTML sebelum → sesudah | Request sebelum → sesudah | Gambar sebelum → sesudah | Waktu muat sebelum → sesudah |
| --- | ---: | ---: | ---: | ---: |
| Beranda | 48.268 → 48.263 B | 49 → 46 | 219.238 → 200.766 B | 639 → 578 ms |
| Jelajahi | 32.288 → 32.418 B | 45 → 44 | 9.758 → 8.184 B | 692 → 504 ms |
| Studi kasus | 17.546 → 17.545 B | 46 → 45 | 18.362 → 16.788 B | 586 → 466 ms |

Pemeriksaan aksi aman mencakup penolakan media pending, pratinjau pemilik, akses publik setelah moderasi, status MongoDB, penolakan CSRF, status sesi kedaluwarsa, dan penolakan penggunaan ulang undangan. Verifikasi produksi yang belum dilakukan mencakup Windows langsung, integrasi SMTP dan WhatsApp sungguhan, monitor produksi, pembaca layar manual, browser selain Chromium, dan pengukuran Core Web Vitals lapangan.
