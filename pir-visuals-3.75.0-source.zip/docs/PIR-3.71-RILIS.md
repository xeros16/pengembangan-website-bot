# PIR Visuals 3.71.0

## Tampilan dan pencarian

- **Jelajahi.** Latar direktori, panel pencarian, kolom input, dan karya pilihan mengikuti tema yang dipilih. Kolom kata kunci dan tombol **Cari** berada dalam satu baris. Pembuka yang lebih ringkas membuat hasil terlihat lebih awal di ponsel.
- **Filter lanjutan.** Tombol **Filter & urutkan** tersedia di desktop dan ponsel. Filter aktif dari URL membuka panel saat halaman dimuat. Saat JavaScript dimatikan, semua filter tetap dapat digunakan lewat formulir.
- **Untuk Bisnis.** Palet tema gelap mencakup pembuka, kartu bidang kreatif, dan panel penjelasan. Bagian **Area kebutuhan kreatif** dan **Alur kolaborasi** memakai hierarki judul yang lebih jelas. Panel penjelasan yang juga digunakan di Tentang dan Cara Kerja mengikuti tema yang dipilih.

## Instalasi dan preview

Gunakan ZIP update dari checkout **3.70.0** atau ZIP source lengkap untuk instalasi baru dan versi lebih lama. Ikuti [panduan instalasi dan rollback](PIR-3.68-INSTALASI.md) untuk konfigurasi MongoDB dan penyimpanan.

Dari folder `portfolio-website`, jalankan `npm ci` dan `npm run preview`. Tunggu status **Listening**, lalu buka `http://127.0.0.1:3080` atau alamat yang tercetak di terminal.

## Verifikasi

- 30 tes Playwright lulus di Chromium desktop dan ponsel. Pengujian memeriksa kontras teks dan kontrol yang dipilih pada tema terang dan gelap dengan ambang 4,5:1, navigasi keyboard, serta pengiriman filter.
- Sembilan smoke test website lulus. Formulir tanpa JavaScript diverifikasi pada lebar 360, 768, dan 1440 piksel.
- Suite Node website mencatat 683 tes lulus dan 130 kegagalan yang sama dengan 3.70.0.
- Screenshot perbandingan memakai data sintetis. Pengujian dilakukan secara lokal.
