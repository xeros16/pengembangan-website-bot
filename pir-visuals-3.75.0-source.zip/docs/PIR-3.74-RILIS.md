# PIR Visuals 3.74.0

- **Galeri Beranda.** Di ponsel dan tablet, karya tampil sebelum deskripsi. Gambar dan video mengikuti proporsi aslinya di dalam bingkai.
- **Navigasi langsung.** Tombol sebelumnya, berikutnya, dan pilihan bernomor tampil di atas karya. Setiap kategori mengingat karya yang terakhir dipilih selama halaman terbuka.
- **Kontrol pengunjung.** Karya berganti ketika dipilih lewat tombol, keyboard, atau geser mendatar pada gambar. Perpindahan memakai transisi singkat yang mengikuti pengaturan pengurangan gerak. Video diputar lewat kontrolnya.

## Instalasi dan preview

Gunakan ZIP update dari **3.73.0** atau ZIP source lengkap untuk instalasi baru dan versi lebih lama. Ikuti [panduan instalasi](PIR-3.68-INSTALASI.md) untuk konfigurasi MongoDB dan penyimpanan.

Dari folder `portfolio-website`, jalankan `npm ci` dan `npm run preview`. Setelah status **Listening**, buka `http://127.0.0.1:3080` atau alamat yang tercetak di terminal.

## Verifikasi

- 36 tes Chromium desktop dan ponsel serta 9 smoke test lulus. Pemeriksaan tambahan mencakup geser mendatar, gulir vertikal, dan pengurangan gerak pada lebar 320 piksel. Karya pembuka tetap bisa dibuka saat JavaScript dimatikan.
- Suite Node mencatat 683 lulus dan 130 kegagalan yang sama dengan 3.73.0.
- ZIP perbandingan berisi delapan screenshot dengan data sintetis pada desktop dan ponsel.
