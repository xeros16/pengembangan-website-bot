# PIR Visuals website audit

20 November 2026. The website package reported version **3.75.0**. The `work` branch was at `c884335` with later work already present in the working tree. The 3.75.0 source archive supplied the comparison baseline. The audit used local Chromium, isolated MongoDB, synthetic designers and projects, and a loopback SMTP sink that accepted only fixture recipients. Production and real user data were outside the test environment.

## Findings and changes

| Priority | Finding | Result |
| --- | --- | --- |
| P0 | A public collection could expose the title of published work after its designer profile became private. The work page and media endpoint already denied access. | Collection rendering now uses the public artwork query and checks visibility on each request. Create and edit use the same eligibility check. |
| P0 | Rejected collection create and update requests discarded the draft. | Both forms render the submitted fields again, announce the error, and allow correction. The create throttle is applied after validation. |
| P1 | The desktop collection form was hidden until scroll triggered its entrance, making its first field unavailable to keyboard focus. | The shared entrance script leaves forms and their containing panels visible. The browser regression exercises focus with motion enabled. |
| P1 | Controls on collection and Studio setup screens lacked programmatic labels. | Added explicit labels and associated collection help text. |
| P1 | The active Lainnya menu showed forest text over a dark green background. | The active disclosure now uses the existing honey navigation token. Measured contrast improved from 1.62:1 on desktop and 1.34:1 on mobile to 9.45:1 on both. |
| P1 | Pressing Escape in Cari cepat with a non-empty query could leave the dialog open. | The dialog now closes on the first Escape and restores focus to its desktop or compact-menu entry point. |
| P1 | Unknown URLs returned HTTP 200 with the directory, masking broken links. | The existing recovery page returns HTTP 404 and links to Discover. The legacy direct designer-ID handler and the case and review handlers resolve before the fallback. |
| P2 | The empty collection preview showed a sample title as if it were user data. | The preview now says “Koleksi tanpa judul”. The single pear, forest, cream and honey theme stays in use. |

## Audit matrix

**Verified** applies to the states in its row. **Fixed and verified** records an implemented change with a reproduced result. **Open** identifies gaps with follow-up steps. **Blocked** gives the missing dependency. **B** is the browser suite, **C** the public render crawl, **J** the synthetic journeys, **F** the targeted comparisons, and **S** the smoke suite. This matrix records sampled coverage.

| Route or flow and entry | Role | States and controls checked | Issue, priority and result | Status | Evidence |
| --- | --- | --- | --- | --- | --- |
| `/` from wordmark and header | Visitor | Header, Discover link, jump to community gallery | Passed exercised journey | Verified | B, C, J1 |
| `/#karya-komunitas` from home | Visitor | Populated category, empty Event and return action, active tab, heading/tab alignment, remembered slide, keyboard/touch and vertical scroll | Passed exercised gallery states | Verified | B |
| Gallery with other media | Visitor | Long caption, video, and broken cover branches identified | P2. Seed a long title and remove one synthetic media file. Exercise all tabs and video controls. | Open | Source |
| Header, compact menu, footer and anchors | Visitor | All 17 distinct internal nav destinations returned HTTP 200. Main header and gallery anchor sampled. | P1. Complete the click-through, then check sticky-header occlusion for all anchors. | Open | B, C, F, partial |
| Lainnya menu from a secondary page | Visitor | Active state contrast, open from keyboard, focus inside menu and Escape return focus on desktop and mobile | P1 contrast fixed with the shared honey background | Fixed and verified | B, F |
| Cari cepat from header or compact menu | Visitor | No results, Escape with a populated query, focus return, keyboard option selection and navigation on Chromium desktop and mobile | P1 keyboard dismissal fixed | Fixed and verified | B, F |
| Profile preview and artwork lightbox | Visitor | Controls found in shared JS | P1. Open each by keyboard, cycle focus, choose a result, dismiss and verify focus return. Repeat with touch. | Open | Source |
| `/discover` from Jelajahi | Visitor / client | Keyword, location, sort, query persistence on Back, filter remove, keyboard disclosure and no-results render | Passed exercised paths | Verified | B, C, J1–2 |
| Discover pagination and history | Visitor / client | 26 profiles matched. Page 1 showed 24 and page 2 showed two. Next, previous, heading counts, profile open, Back, Forward, sort, filter state and reload agreed. | Passed exercised paths | Verified | B, F |
| Discover additional filters | Visitor / client | Query, location, sort and filter removal verified separately | P1. Exercise budget, skill and availability combinations against dated synthetic availability records. | Open | B, partial |
| `/categories`, `/categories/branding` from navigation | Visitor | Index and branding page rendered on mobile and desktop | P2. Activate all tiles and match each filter and count to the seeded dataset. | Open | C, render only |
| `/designer/:id` and direct designer ID | Visitor / client | Main profile and next action exercised. Both paths returned HTTP 200 with the same profile. | Legacy ID alias reached after the 404 fix | Fixed and verified | B, C, F, J3 |
| `/p/:slug` and incomplete profiles | Visitor / client | Click-through from a paginated result rendered the expected slug profile | P1. Check long fields, optional-field fallbacks and incomplete data for all profile layouts. | Open for incomplete profile states | F |
| `/work/:id`, public `/media` and sitemap from Discover and profile | Visitor | Approved work and cover load. Private fixture excluded. Pending upload becomes public after approval. | Passed exercised publication states | Verified | B, C, J6, J9 |
| `/for-business` from header | Visitor / client | Responsive render and sampled text contrast | P2. Exercise all calls to action and embedded workflow at target widths. | Open | B, C, partial |
| `/about`, `/how-it-works`, `/privacy`, `/terms` from footer | Visitor | Title and responsive render | P2. Follow each in-page link and check reading/focus order at real desktop zoom. | Open | C, render only |
| `/commands`, `/creative-studio` from navigation | Visitor | Responsive render | P2. Exercise search, filters, copy, reset and each feature or studio call to action. | Open | C, render only |
| `/favorites` from profile and footer | Visitor | Save and find a designer in the same browser context | Passed tested saved state | Verified | C, J3 |
| `/shortlist` and compare from profile | Client | Save a profile and open shortlist | P1. Compare multiple profiles, remove one, reload and test missing/private records and empty state. | Open | C, J3, partial |
| `/collections`, create from navigation | Visitor / client | Focus with motion active, reject invalid ID, preserve draft and checkbox, correct and create | P0 draft loss, P1 labels and focus, and P2 empty title fixed | Fixed and verified | B, F |
| `/collections/:slug` from share link | Visitor / client | Legacy public board with private-author work. Newly created board links to eligible work. | P0 private title leak fixed | Fixed and verified | F |
| Collection edit from management link | Collection editor | Invalid edit preserved title and IDs, corrected update saved | P0 draft loss fixed | Fixed and verified | F |
| Collection reordering, privacy switch, deletion and stale link | Collection editor | Handlers and UI inventoried | P1. Reorder, switch to private, reopen the share link without an edit session, delete, and reopen both links. Exercise duplicate submit. | Open | Source, F partial |
| `/contact` support from footer | Visitor | Public page rendered | P1. Submit valid and malformed fixture tickets and resolve one in Owner dashboard. | Open | C, render only |
| `/contact/:id` brief from profile | Client | Invalid draft, correction, successful send to loopback SMTP | Passed exercised recovery path | Verified | B, C, J12 |
| `/out/:id` WhatsApp handoff | Client | Local handoff destination checked | Messaging requires a dedicated test WhatsApp account and isolated bot session. | Blocked | B, J3 verify local handoff |
| `/client`, `/client/access`, `/client/projects/:id` from email or footer | Client | Confirmation, one-time link, active stage, token replay and cross-project denial | Passed exercised access states | Verified | B, C, J13 |
| Client project feedback and logout | Client | Feedback persists, rate-limited retry retains draft, invalid CSRF denied, logout and expired session | Passed exercised paths | Verified | J14–16 |
| `/studio`, `/studio/login` from Portal desainer | Designer | Mobile and desktop login layout, OTP guidance, account help and seeded OTP redemption | Passed exercised sign-in | Verified | B, C, J4 |
| WhatsApp OTP issue and delivery | Designer | Local login uses a seeded code | End-to-end delivery requires an isolated PIR bot session and registered test number. | Blocked | J4 verifies redemption |
| Studio register, forgot, reset, verify, resend, password change | Designer | Public screens rendered for register and forgot. Related handlers inventoried. | P1. Register a fixture and use loopback SMTP to verify and reset its password. Test expiration and replay, then sign in. | Open | C, source |
| `/studio/setup` from onboarding | Designer | Four previously unnamed controls now labeled | P1 labels fixed | Fixed and verified | C, F |
| Studio setup submit | Designer | Setup page and POST handler identified | P1. Seed a valid setup request, then submit invalid and valid values. | Open | C, source |
| Studio profile, avatar preview and private media | Designer | Profile saved and pending work preview rendered | P1. Test avatar upload, unsupported format, save and remove. | Open for avatar | J5–6, profile save verified |
| Studio work upload and edit | Designer | Pending upload, private preview, public denial, saved edit | Passed exercised save states | Verified | J6–7 |
| Studio upload limits, interruption and retry | Designer | Successful submission verified separately | P1. Abort an upload, retry and check file storage and database for duplicate records. Use fixtures at file/count limits. | Open | J6, partial |
| Studio services and availability | Designer | Service creation and availability update | Passed exercised saves | Verified | J8 |
| Studio leads, collections, testimonials, services delete/reorder and workspace changes | Designer | Workspace renders, client feedback syncs and anonymous access denied | P1. Exercise milestones, attachments, closure and logout. Test lead status, service delete/reorder, and publish/unpublish collections and testimonials. | Open | B, J15, partial |
| Owner dashboard and CMS | Owner | Local auth, queue jump, health, CMS edit and published result | Passed exercised CMS edit | Verified | J9, J11 |
| Owner approve and reject | Owner | Approval publishes synthetic work. Rejection leaves work unavailable. | Passed both moderation paths | Verified | J9–10 |
| Owner work pin/unpublish, designer visibility, admin media, support and review | Owner | Handlers and dashboard surface inventoried | P1. Use a separate fixture for each control and check cancel/confirm, authorization, persisted state and public result. | Open | Source, J9–11 partial |
| Public review and verification | Client / owner | Submit, verify and moderate handlers inventoried | P1. Submit a fixture review, consume local verification link, then exercise both moderation outcomes. | Open | Source |
| Unknown URL and recovery page | Visitor | Unknown URL, explanation and Discover link | P1 returns actual 404 with recovery | Fixed and verified | B, C, F |
| Health, robots, sitemap, manifest, service worker and animation runtimes | Visitor / operator | HTTP availability and database readiness | Passed the smoke suite | Verified | S, B for sitemap visibility |
| API, QR, install/offline and slow or failed loading | Visitor / operator | API and QR handlers identified, service worker script serves | P2. Exercise favorites under API throttle/error, PWA install/offline, QR and sampled telemetry with fixture records. | Open | Source and S, partial |
| Shared motion, motion control and reduced motion | Visitor | Site toggle, dark system preference with single palette, reduced motion and editorial entrance sampled | P1 form focus fixed. Dialogs and authenticated views need their own motion/focus passes. | Fixed and verified | B, F |
| Chromium 200% desktop zoom | Visitor / designer | Home, Discover, collection, Studio sign-in, Studio setup and For Business. Collection focus stayed below the sticky header. | No document-level horizontal overflow in six sampled routes | Verified | F |
| Accessibility across browsers and remaining focus paths | All roles | Sampled Chromium reflow, contrast and focus | P1. Repeat in Firefox/Safari and with screen readers. Check target sizes, sticky headers and full focus order. | Open | B, C, F, partial |

## Live reference notes

| Reference | Observed pattern | Application to PIR |
| --- | --- | --- |
| <https://bettr.academy/> | Editorial headings and distinct color bands group information visually. | Used as a reference when checking PIR’s existing palette and hierarchy. PIR retains its own pear branding and artwork. |
| <https://www.behance.net/> | The requested homepage returned HTTP 400 from the audit environment. | Portfolio discovery was checked directly on PIR with synthetic work. |
| <https://www.awwwards.com/> | Award listings link to original studio pages. | Used to scope studio references. |
| <https://locomotive.ca/en> | The studio’s public homepage organizes its portfolio around individual projects with short links to case studies. | Used to review PIR’s existing Discover-card-to-case-study flow. The link and cover worked with local portfolio media. |
| <https://design-system.service.gov.uk/components/error-summary/> | Focused and announced validation feedback helps users recover after a form submission. | Adapted the focused error notice and associated help for PIR’s Indonesian collection forms. Submitted drafts remain available for correction. |

## Verification and evidence

- `npm run check` checked 387 JavaScript files. `npm run website:check` and `git diff --check` passed.
- `npm run website:test` ran 813 tests with 683 passing and 130 failing in both baseline and patched runs. The failure-name multisets matched. Some existing assertions target earlier markup.
- Website smoke checks passed 9 of 9. All 46 Chromium desktop and mobile Playwright cases passed across the suite and its isolated retry. The mobile contrast case timed out during the parallel run and passed on retry.
- Sixteen synthetic journey checks exercised visitor discovery, Studio, owner moderation, client access, feedback and logout. The SMTP check used loopback delivery.
- Chromium public crawl recorded 65 renders per version across 25 URLs. Routes were checked at 390 and 1280 CSS pixels. Home, Discover, collections, Studio and business were also checked at 320, 768, and 1680. The final sample recorded 63 HTTP 200s, two expected HTTP 404s, zero uncaught browser page errors and zero document-level horizontal overflow. Discover and Studio at 1680 timed out under parallel load and passed on an isolated retry.
- Chromium Page Zoom was set to 200% in the browser settings, reducing a 1280 px window to 640 CSS px. Six routes had zero document-level horizontal overflow in both versions.
- At 390 × 844, three cold browser contexts blocked external resources and sampled layout shifts for 500 ms after fonts settled. Observed CLS was 0 for the sampled collections and Studio setup renders before and after.
- Screenshot pairs use the same routes, matched viewport dimensions and synthetic data. Desktop recordings show the form focus and quick-search dismissal with motion enabled.

## Local preview and reproduction

Set `MONGO_URI` to an isolated synthetic database using the root `.env` or the process environment. From the repository root run:

    npm ci --prefix portfolio-website
    npm run preview --prefix portfolio-website

Open <http://127.0.0.1:3080/>. The preview command was verified with the isolated database and a custom `PIR_PREVIEW_PORT`. The preview script uses loopback HTTP and disables SMTP. To exercise sending, start `node portfolio-website/server.js` in development mode using loopback host and base URL, synthetic MongoDB, separate upload storage, and local SMTP. The smoke test reads `PORTFOLIO_SMOKE_BASE_URL`. For Playwright, set `E2E_BASE_URL`, `E2E_EXTERNAL_SERVER=true`, `E2E_DESIGNER_PATH`, and the portfolio and collection fixtures referenced by `e2e/editorial-edition.spec.js`.

1. **Draft recovery.** Open `/collections`, enter a title and description, uncheck publication, enter `ID tidak valid` as an artwork ID, and submit. Expect HTTP 400, a focused notice, and all entered values. Replace the ID with seeded public artwork. Expect HTTP 201 and a working board. From the management link, repeat with an invalid ID, correct it and save. Expect HTTP 200 and the revised board.
2. **Legacy collection visibility.** In the synthetic database, seed a public board that references published artwork, then change its owner’s profile to private. Fetch the board in a fresh browser. The baseline HTML contains the private artwork title. The patched HTML omits it and still includes any eligible public work.
3. **Desktop form focus.** At 1280 × 800, keep site motion on and system motion at no preference. Open `/collections` at the top and focus the name field before manually scrolling. The patched field accepts focus and input immediately.
4. **Missing route.** Open `/audit-missing-route`. Expect HTTP 404, the Indonesian recovery heading and a working Discover link. The baseline returned the directory and HTTP 200.
5. **Quick search dismissal.** Open Cari cepat, type a phrase with no matching destination, and press Escape once. Expect the dialog to close and focus to return to Cari cepat on desktop or Menu on mobile.
6. **Open and blocked flows.** Use the scenario and fixture described in each matrix row. Real end-to-end delivery requires dedicated test accounts, especially for the WhatsApp bot.
